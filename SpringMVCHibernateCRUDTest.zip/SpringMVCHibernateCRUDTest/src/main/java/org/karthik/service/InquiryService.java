package org.karthik.service;

import java.util.List;

import org.karthik.dao.InquiryDAO;
import org.karthik.domain.Inquiry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("InquiryService")
public class InquiryService {

	@Autowired
	InquiryDAO inquiryDao;
	
	@Transactional
	public List<Inquiry> getAllinquiriess() {
		return inquiryDao.getAllinquiriess();
	}

	@Transactional
	public Inquiry getinquiry(int id) {
		return inquiryDao.getinquiry(id);
	}

	@Transactional
	public void addinquiry(Inquiry inquiry) {
		inquiryDao.addinquiry(inquiry);
	}

	@Transactional
	public void updateinquiry(Inquiry inquiry) {
		inquiryDao.updateinquiry(inquiry);

	}

	@Transactional
	public void deleteinquiry(int id) {
		inquiryDao.deleteinquiry(id);
	}
}
