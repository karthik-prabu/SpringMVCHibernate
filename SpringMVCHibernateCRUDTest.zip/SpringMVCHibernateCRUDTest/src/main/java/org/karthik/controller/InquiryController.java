package org.karthik.controller;


import java.util.List;

import org.karthik.domain.Inquiry;
import org.karthik.service.InquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class InquiryController {
	
	@Autowired
	InquiryService inquiryService;
	
	@RequestMapping(value = "/getAllinquiriess", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getAllInquiry(Model model) {
		
		List<Inquiry> listOfinquiries = inquiryService.getAllinquiriess();
		model.addAttribute("inquiry", new Inquiry());
		model.addAttribute("listOfinquiries", listOfinquiries);
		return "inquiryDetails";
	}

	@RequestMapping(value = "/getinquiry/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public Inquiry getInquiry(@PathVariable int id) {
		return inquiryService.getinquiry(id);
	}

	@RequestMapping(value = "/addInquiry", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addInquiry(@ModelAttribute("inquiry") Inquiry inquiry) {	
		if(inquiry.getId()==0)
		{
			inquiryService.addinquiry(inquiry);
		}
		else
		{	
			inquiryService.updateinquiry(inquiry);
		}
		
		return "redirect:/getAllinquiriess";
	}

	@RequestMapping(value = "/updateinquiry/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String updateInquiry(@PathVariable("id") int id,Model model) {
		 model.addAttribute("inquiry", this.inquiryService.getinquiry(id));
	        model.addAttribute("listOfinquiries", this.inquiryService.getAllinquiriess());
	        return "inquiryDetails";
	}

	@RequestMapping(value = "/deleteinquiry/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String deleteInquiry(@PathVariable("id") int id) {
		inquiryService.deleteinquiry(id);
		 return "redirect:/getAllinquiriess";

	}	
}
